The ZIP distrubution is to be used without the IDE


License setup
=============

Run Configuration Wizard from bin/jrebel-config.{cmd|sh} and follow the steps to setup the license
